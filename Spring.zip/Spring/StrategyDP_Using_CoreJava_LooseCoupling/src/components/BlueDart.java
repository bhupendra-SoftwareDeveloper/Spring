package components;

public class BlueDart implements Courier
{
	@Override
	public String delivery(int oid)
	{
		
		return "BlueDart Courier will return "+oid+" order products";
	}

}
