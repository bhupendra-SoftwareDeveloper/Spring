package components;

public class DTDC implements Courier
{
	public String delivery(int oid)
	{
		return "DTDC Courier will return "+oid+" order products";
	}
}
