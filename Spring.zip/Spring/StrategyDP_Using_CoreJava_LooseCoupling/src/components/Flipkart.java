package components;

import java.util.Arrays;
import java.util.Random;

public class Flipkart
{
	private Courier courier;

	public void setCourier(Courier courier) {
		this.courier = courier;
	}
	
	public String shopping(String[]items, float[]price)
	{
		float bill=0.0f;
		int oid=0;
		String msg=null;
		//TotalBill
		for(float f:price)
			bill+=f;
		
		//Taking Random orderId
		oid=new Random().nextInt(1000);
		
		msg=courier.delivery(oid);
		
		return Arrays.toString(items)+" with price "+Arrays.toString(price)+" and Total Bill is: "+bill+"\n"+msg;
	}
}
