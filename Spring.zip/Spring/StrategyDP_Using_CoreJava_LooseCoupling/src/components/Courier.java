package components;

public interface Courier
{
	String delivery(int oid);
}
