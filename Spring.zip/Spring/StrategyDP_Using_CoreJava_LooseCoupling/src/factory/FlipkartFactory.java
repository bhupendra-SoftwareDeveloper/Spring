package factory;

import components.Courier;
import components.DTDC;
import components.Flipkart;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import components.BlueDart;

public class FlipkartFactory
{
	private static Properties prop;
	
	static {
		prop=new Properties();
		
		try {
			InputStream is= new FileInputStream("src/commonProperty/StrategyDP.properties");
			prop.load(is);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Flipkart getInstance() throws Exception
	{
		Courier courier;
		Flipkart fpkt;
		courier=(Courier)Class.forName(prop.getProperty("components.dependent")).newInstance();
		fpkt=new Flipkart();
		fpkt.setCourier(courier);
		
		return fpkt;
	}
}
