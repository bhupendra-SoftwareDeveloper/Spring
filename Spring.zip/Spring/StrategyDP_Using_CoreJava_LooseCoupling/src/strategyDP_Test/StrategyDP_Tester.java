package strategyDP_Test;

import components.Flipkart;
import factory.FlipkartFactory;

public class StrategyDP_Tester {

	public static void main(String[] args) throws Exception
	{
		Flipkart fpkt=null; 
		
		fpkt=FlipkartFactory.getInstance();
		
		System.out.println(fpkt.shopping(new String[]{"RainCoat","Umbrella","FluTablets"}, new float[] {1500,900,452}));
	}

}
