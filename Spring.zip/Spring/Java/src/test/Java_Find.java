package test;
import java.io.FileInputStream;
import java.io.IOException;

public class Java_Find
{
	void find() throws IOException
	{
		FileInputStream fis=new FileInputStream("D:\\B.txt");
		int i,c=0,count=0;
		String j="";
		while((i=fis.read())!=-1)
		{
			if(((char)i)=='J')
			{
				c++;
			}
			if(c==1)
			{
				if(((char)i)=='a')
				{
					c++;
				}
			}
			if(c==2)
			{
				if(((char)i)=='v')
				{
					c++;
				}
			}
			if(c==3)
			{
				if(((char)i)=='a')
				{
					count++;
					c=0;
				}
			}
		}
		System.out.println("Total java occured: "+count);
		fis.close();
	}
	public static void main(String[] args) throws Exception
	{
		Java_Find jf=new Java_Find();
		jf.find();
	}

}
