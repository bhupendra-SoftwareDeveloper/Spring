package demo;

public class Airtel implements Sim
{
	public void calling()
	{
		System.out.println("We Are Calling Using Airtel Sim...");
	}
	public void internet()
	{
		System.out.println("We Are Using Airtel 4G Internet..");
	}
}
