package demo;

public interface Sim
{
	void calling();
	void internet();
}
