package demo;

public class Jio implements Sim
{
	public void calling()
	{
		System.out.println("We Are Calling Using Jio Sim...");
	}
	public void internet()
	{
		System.out.println("We Are Using Jio 4G Internet..");
	}
}
