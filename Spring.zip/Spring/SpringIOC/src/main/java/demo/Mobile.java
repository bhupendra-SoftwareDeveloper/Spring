package demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Mobile 
{
	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		ApplicationContext cont=new ClassPathXmlApplicationContext("bean.xml");
		Sim sim=cont.getBean("sim",Sim.class);
		sim.calling();
		sim.internet();
	}
}
