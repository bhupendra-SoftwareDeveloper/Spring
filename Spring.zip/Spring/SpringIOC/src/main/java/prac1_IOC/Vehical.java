package prac1_IOC;

public interface Vehical
{
	void company();
	void type();
}
