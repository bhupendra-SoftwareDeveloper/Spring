package prac1_IOC;

public class Jeep implements Vehical
{
	public void company()
	{
		System.out.println("Mahindra is the company of this Jeep...");
	}
	public void type()
	{
		System.out.println("Jeep is Thar...");
	}
}
