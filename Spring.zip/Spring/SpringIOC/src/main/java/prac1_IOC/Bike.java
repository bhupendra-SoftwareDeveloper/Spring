package prac1_IOC;

public class Bike implements Vehical
{
	public void company()
	{
		System.out.println("Hero is the company of this Bike...");
	}
	public void type()
	{
		System.out.println("Bike is Splender...");
	}
}
