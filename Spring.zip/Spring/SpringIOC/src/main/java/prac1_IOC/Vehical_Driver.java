package prac1_IOC;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Vehical_Driver
{
	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		ApplicationContext cont=new ClassPathXmlApplicationContext("bean.xml");
		Vehical v=cont.getBean("vehical",Vehical.class);
		v.company();
		v.type();
	}
}
