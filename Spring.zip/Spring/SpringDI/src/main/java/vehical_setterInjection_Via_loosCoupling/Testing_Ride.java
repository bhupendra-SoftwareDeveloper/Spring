package vehical_setterInjection_Via_loosCoupling;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Testing_Ride {

	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		ApplicationContext cont=new ClassPathXmlApplicationContext("beanVehical.xml");
		Rider rider=cont.getBean("rider",Rider.class);
		
		rider.ride();
	}

}
