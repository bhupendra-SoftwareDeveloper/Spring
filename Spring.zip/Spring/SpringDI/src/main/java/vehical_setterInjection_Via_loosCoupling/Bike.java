package vehical_setterInjection_Via_loosCoupling;

public class Bike implements Vehical
{
	public void drive()
	{
		System.out.println("I Am Driving Bike...");
	}
}
