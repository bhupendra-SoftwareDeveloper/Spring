package vehical_setterInjection_Via_loosCoupling;

public interface Vehical
{
	void drive();
}
