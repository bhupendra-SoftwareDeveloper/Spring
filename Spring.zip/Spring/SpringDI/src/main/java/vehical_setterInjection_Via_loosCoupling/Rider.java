package vehical_setterInjection_Via_loosCoupling;

public class Rider {
	private Vehical vehical;

	public void setVehical(Vehical vehical) {
		this.vehical = vehical;
	}

	void ride() {
		vehical.drive();
	}
}
