package vehical_setterInjection_Via_loosCoupling;

public class Scooty implements Vehical
{
	public void drive()
	{
		System.out.println("I Am Driving Scooty...");
	}
}
