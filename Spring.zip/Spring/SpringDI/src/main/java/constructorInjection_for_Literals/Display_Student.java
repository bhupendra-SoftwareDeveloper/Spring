package constructorInjection_for_Literals;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Display_Student
{
	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		ApplicationContext cont=new ClassPathXmlApplicationContext("beanLiterals.xml");
		Student stud=cont.getBean("student",Student.class);
		
		stud.display();
	}

}
