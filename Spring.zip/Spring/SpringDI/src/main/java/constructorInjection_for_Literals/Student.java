package constructorInjection_for_Literals;

public class Student
{
	private String studName;
	private int id;
	
	public Student(String studName, int id) {
		super();
		this.studName = studName;
		this.id = id;
	}
	
	void display()
	{
		System.out.println("Student Name: "+studName+" And id is: "+id);
	}
}
