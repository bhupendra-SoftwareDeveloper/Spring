package qualifierAnnotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Lion {
	@Autowired
	@Qualifier("ani2")
	Animal animal;

	void haunt() {
		if (animal != null) {
			animal.life();
			System.out.println(
					"In this forest, Total " + animal.getNoOfAnimal() + " " + animal.getName() + " are living...");
		} else
			System.out.println("Animal is dead...");
	}
}
