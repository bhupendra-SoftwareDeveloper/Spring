package qualifierAnnotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Forest
{
	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		ApplicationContext cont=new ClassPathXmlApplicationContext("beanAutowiredAnnotation.xml");
		Lion lion=cont.getBean("lion",Lion.class);
		
		lion.haunt();
	}
}
