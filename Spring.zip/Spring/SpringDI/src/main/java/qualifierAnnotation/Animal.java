package qualifierAnnotation;

public class Animal {
	private String name;
	private int noOfAnimal;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNoOfAnimal() {
		return noOfAnimal;
	}

	public void setNoOfAnimal(int noOfAnimal) {
		this.noOfAnimal = noOfAnimal;
	}

	void life() {
		System.out.println("Animal Is Alive...");
	}
}
