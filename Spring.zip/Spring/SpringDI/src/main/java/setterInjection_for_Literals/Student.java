package setterInjection_for_Literals;

public class Student
{
	private String studentName;
	private int id;
	
	public void setStudentName(String studentName)
	{
		this.studentName = studentName;
	}
	
	public void setId(int id) {
		this.id = id;
	}


	void display()
	{
		System.out.println("Student Name: "+studentName+" And id is: "+id);
	}
}
