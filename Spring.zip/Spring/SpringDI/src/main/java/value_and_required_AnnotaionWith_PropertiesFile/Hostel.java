package value_and_required_AnnotaionWith_PropertiesFile;

import org.springframework.beans.factory.annotation.Value;

public class Hostel {
//	@Value("Rajesh")	//Another Way-->2
	@Value("${hostel.name}")
	private String name;
	
//	@Value("4500")		//Another Way-->2
	@Value("${hostel.rent}")
	private int rent;
	
//	@Value("405")		//Another Way-->2
	@Value("${hostel.room}")
	private int roomNo;

/*
	@Value("Rajeshwari")	//Another Way-->1
	public void setName(String name) {
		this.name = name;
	}
	@Value("4500")			//Another Way-->1
	public void setRent(int rent) {
		this.rent = rent;
	}
	@Value("405")			//Another Way-->1
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
*/
	void displayDetails() {
		System.out.println(name + " is paying " + rent + " for RoomNo " + roomNo);
	}
}
