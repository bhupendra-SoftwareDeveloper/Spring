package value_and_required_AnnotaionWith_PropertiesFile;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Hostel_Executer {

	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		ApplicationContext cont=new ClassPathXmlApplicationContext("beanValue_RequiredAnnotation.xml");
		Hostel hostel=cont.getBean("hostel",Hostel.class);
		
		hostel.displayDetails();
	}

}
