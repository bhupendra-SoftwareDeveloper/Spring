package setterInjection_for_Object;

public class Person1
{
	private Vehical v;
	
	public void setV(Vehical v) {
		this.v = v;
	}

	void riding()
	{
		System.out.print("Person1 is driving and ");
		v.drive();
	}
}
