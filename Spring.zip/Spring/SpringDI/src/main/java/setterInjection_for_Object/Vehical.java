package setterInjection_for_Object;

public class Vehical
{
	
	void drive()
	{
		System.out.println("Vehical is running...");
	}
}
