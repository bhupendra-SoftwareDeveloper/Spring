package setterInjection_for_Object;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Vehiacl_Driver {

	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		ApplicationContext cont=new ClassPathXmlApplicationContext("beanObject.xml");
		Person1 p=cont.getBean("person",Person1.class);
		p.riding();
		
		Person2 p2=cont.getBean("person2",Person2.class);
		p2.riding();
	}

}
