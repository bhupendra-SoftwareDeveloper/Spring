package autoWiredAnnotation;

public class Animal
{
	void life()
	{
		System.out.println("Animal Is Alive...");
	}
}
