package autoWiredAnnotation;

import org.springframework.beans.factory.annotation.Autowired;

public class Lion {
	Animal animal;
	@Autowired
	public void setAnimal(Animal animal) {
		System.out.println("setter...");
		this.animal = animal;
	}

	public Lion() {
		System.out.println("Non");
	}
	
	public Lion(Animal animal) {
		super();
		System.out.println("constructor...");
		this.animal = animal;
	}

	void haunt() {
		if (animal != null)
			animal.life();
		else
			System.out.println("Animal is dead...");
	}
}
