package postConstruct_PreDestroyAnnotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test_Executer
{
	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		ApplicationContext cont=new ClassPathXmlApplicationContext("beanPostConstruct_PreDestroy.xml");
		Test test=cont.getBean("sample",Test.class);
		
		test.sample();
	//	((ClassPathXmlApplicationContext)cont).close(); //(1-approach)We need to downcast because close() is in ClassPathXmlApplicationContext
		((ClassPathXmlApplicationContext)cont).registerShutdownHook();//(2-approach)
	}
}
