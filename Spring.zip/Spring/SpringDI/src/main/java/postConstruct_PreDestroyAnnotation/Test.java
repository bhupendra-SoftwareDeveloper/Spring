package postConstruct_PreDestroyAnnotation;

public class Test
{
	public void init()
	{
		System.out.println("This is init method which is executing first...");
	}
	
	public void sample()
	{
		System.out.println("This is sample method...");
	}

	public void destroy()
	{
		System.out.println("This is destroy method which is executing last...");
	}
}
