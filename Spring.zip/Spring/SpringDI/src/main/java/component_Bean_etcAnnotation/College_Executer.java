package component_Bean_etcAnnotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class College_Executer {

	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		ApplicationContext cont = new AnnotationConfigApplicationContext(College_Configure.class);
		College clg=cont.getBean("college",College.class);
		
		clg.exam();
	}

}
