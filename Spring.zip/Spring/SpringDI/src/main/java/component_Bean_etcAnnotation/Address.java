package component_Bean_etcAnnotation;
import org.springframework.stereotype.Component;

@Component
public class Address
{
	void collegeAddress()
	{
		System.out.println("College Address: Harinagar-1 Udhna Surat Gujarat.");
	}
}
