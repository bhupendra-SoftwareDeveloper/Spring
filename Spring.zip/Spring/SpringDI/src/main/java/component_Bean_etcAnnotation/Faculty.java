package component_Bean_etcAnnotation;

public interface Faculty
{
	void teaching();
}
