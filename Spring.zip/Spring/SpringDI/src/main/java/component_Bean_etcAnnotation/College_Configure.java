package component_Bean_etcAnnotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages="component_Bean_etcAnnotation")
public class College_Configure
{
	/*
	@Bean
	public Faculty javaFaculty()
	{
		return new JavaFaculty();
	}*/
	@Bean
	public Faculty phpFaculty()
	{
		return new PhpFaculty();
	}
}
