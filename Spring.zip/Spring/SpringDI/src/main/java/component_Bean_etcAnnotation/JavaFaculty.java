package component_Bean_etcAnnotation;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class JavaFaculty implements Faculty
{
	public void teaching()
	{
		System.out.println("Hello I am Your JAVA Faculty.My Name is Nisha Medhat...");
	}
}
