package component_Bean_etcAnnotation;

public class PhpFaculty implements Faculty
{
	public void teaching()
	{
		System.out.println("Hello I am Your PHP Faculty.My Name is Chirag Patel...");
	}
}
