package component_Bean_etcAnnotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class College {
	private Address clgAdd;
	private Faculty faculty;

	@Autowired
	public void setClgAdd(Address clgAdd) {
		this.clgAdd = clgAdd;
	}

	@Autowired
	@Qualifier("phpFaculty")
	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}


	void exam() {
		System.out.println("Exam start...");
		clgAdd.collegeAddress();
		faculty.teaching();
	}
}
